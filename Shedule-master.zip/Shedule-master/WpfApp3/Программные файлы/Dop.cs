﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3.EF.TableClasses
{
    public class Dop
    {
        public int c {  get; set; }
        public int b { get; set; }
    }
}
